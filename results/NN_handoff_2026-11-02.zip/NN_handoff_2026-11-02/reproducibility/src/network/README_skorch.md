# 调包版本：只自行组合论文损失

入口：`src/network/network_train_skorch.py`。

- 网络、Adam、基础 CE/BCE 损失：PyTorch。
- epoch/batch 训练、反向传播、早停、预测：skorch 的 `NeuralNetClassifier.fit/predict` 和 callbacks。
- 指标：sklearn/scipy；数据读取、划分和预处理：组员的现有接口。
- 自己写的部分：把库提供的基础损失组合为论文 CE、OVR、OVO，以及组织论文的学习率搜索/外层测试实验。

现成的独立 sigmoid BCE 不等于论文 OVR。这里把每类 logit 转成 `f_i - logsumexp(其他类别 logits)`，再调用 `BCEWithLogitsLoss`；其 sigmoid 概率正好等于原多分类 softmax 概率，因此保持论文式 (9)。OVO 直接把 `f_y-f_j` 送入同一个 BCE 模块，再组合类别对权重。没有手写 BCE 或 Adam 的内部公式。

## 运行

当前项目已经创建 `.venv`，复用本机现有 Python 3.11 环境的基础依赖，并安装 skorch 1.4.0。在项目根目录运行：

```powershell
.\.venv\Scripts\python.exe -m src.network.network_train_skorch --datasets CAR
```

其他组员安装依赖后可使用自己的 Python 环境运行：

```powershell
python -m pip install -r src/network/requirements_skorch.txt
python -m src.network.network_train_skorch --datasets CAR
```

快速试跑（三种损失、第一折、一个学习率、3 轮）：

```powershell
.\.venv\Scripts\python.exe -m src.network.network_train_skorch --datasets CAR --criteria macro_f1 --folds 1 --learning-rates 0.001 --max-epochs 3
```

全部数据集使用 `--datasets ALL`。单独实验可加 `--losses ovo --criteria macro_f1`。

默认输出 `D:\CSIT5210PROJECT\results\neural_network_skorch`，每组有参数/指标/训练历史 JSON 与逐样本预测 CSV。同一组同名实验再次运行会覆盖；可用 `--output-dir` 区分不同设置。

## 查看和复现数据划分

新结果中 `fold_results[].sample_counts` 只显示 `train_val`、`inner_train`、`inner_val`、`test` 的数量。顶层 `split_config` 保存划分规则、seed、数据指纹和 sklearn/pandas 版本，替代原来的四个索引长列表；已有结果文件保留原样。

需要查看某折哪些样本属于训练/验证/测试时，运行（替换为自己的报告路径和折号）：

```powershell
.\.venv\Scripts\python.exe -m src.network.reproduce_split --report results/neural_network_skorch/CAR_ovo_macro_f1_folds12345_seed42.json --fold 1
```

工具无需训练模型，输出到 `results/splits` 的 CSV 每行是一条加载后的样本，包含 `sample_index`、标签、`outer_partition`（train_val/test）和 `inner_partition`（train/validation/not_used）。索引从0开始，对应 `load_dataset` 返回的 `X.iloc`，不是原始文件的行号。外层测试集在内层标为 `not_used`。

复现需使用相同数据内容/顺序、划分代码和记录的 sklearn/pandas 版本；工具自动检查指纹与版本。分区使用原始 seed（默认42），不是训练网络的 seed+fold。换电脑用 `--data-dir` 指向相同数据；用 `--output` 指定导出位置。工具兼容旧报告，并可用旧报告的完整索引核对结果。

## 实验约定

- d -> 128 -> 64 -> k，隐藏层各接 LayerNorm、ReLU、Dropout(0.1)。batch size 8，Adam，最多 40 轮，验证标准连续 10 轮无严格提升早停。
- 8 个论文学习率；以 Accuracy 或 Macro-F1 选参。内层只使用第一个五折划分。
- 选定参数后，在外层全部训练数据重新拟合预处理、新建模型重训；轮数取内层最佳 epoch（论文未明确重训早停的实现约定）。测试折不用于调参。
- OVO 权重来自当前完整训练分区的计数，保留式 (12) 的系数 2 和完整目标尺度。所有版本以同一 k 维输出的 argmax 预测。
- 五折预测合并后计算指标；显式保留全部 k 类，零分母计 0。只跑部分折会标记 PARTIAL RUN，不能当作完整论文结果。
- Adam betas=(0.9, 0.999)、epsilon=1e-8、无 weight decay；种子42是实现选择。

skorch 文档：https://skorch.readthedocs.io/en/stable/classifier.html
