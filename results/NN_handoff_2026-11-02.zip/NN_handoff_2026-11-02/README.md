# 神经网络结果交接

本包包含本次正式 GPU 运行的 17 个数据集、CE/OVR/OVO 三种损失、Accuracy/Macro-F1 两种选参标准，合计 102 组实验。每组均完成外层五折。只包含神经网络部分，不包含 SVM 结果。

## 做对比先看哪些文件

1. `NN_results_summary.xlsx`：直接查看和交流结果。Overall 是 17 个数据集的等权平均及 OVO 相对 OVR 的变化；Imbalance groups 是按不平衡程度分组的均值；Results 是 102 组逐数据集结果。
2. `summary_metrics.csv`：建议作为与 SVM/论文结果合并的主数据。每行唯一对应 `dataset + selection_criterion + loss`。CSV 指标使用 0~1 小数，Excel 显示为百分比。
3. `overall_means.csv`、`imbalance_group_means.csv`：总体/分组均值，便于脚本绘图和填表。
4. `raw_reports/`：完整的 102 个 JSON 与 102 个预测 CSV，用于核查、计算其他指标、绘制混淆矩阵。不要丢弃或修改这些原始结果。
5. `fold_details.csv`：510 个测试折的指标、最佳学习率、重训轮数和分区数量。
6. `audit_report.json`、`source_manifest.csv`：核查结论及原始文件 SHA-256，可确认交接前后文件一致。

如果只想先交换数字，发送汇总 Excel 和 `summary_metrics.csv` 即可；完整交接建议发送整个 ZIP，保留原始预测和参数证据。无需发送 `.venv`、缓存、临时试跑目录或 GPU 计时目录。

## 对比规则

- 只比较同一个 `dataset`、相同 `selection_criterion`。`accuracy` 表示用验证集准确率选超参数，`macro_f1` 表示用验证集 Macro-F1 选超参数，二者不能混成一组。
- NN 的 `ovr/ovo` 可分别与 SVM 的 OVR/OVO 对齐；NN 的 `ce` 是另一条基线，不应强行当成 SVM 的某个分解方法。
- 每个数据集先合并五折逐样本预测，计算 Accuracy、Macro-F1、G-mean、BA；表中跨数据集均值再对 17 个数据集等权平均。不要先平均五折 F1/G-mean，也不要把不同数据集的样本拼在一起算一个分类指标。
- 低/中/高不平衡组按数据登记表划分：IR<3、3<=IR<9、IR>=9，分别含 3、5、9 个数据集。
- CSV 与 JSON 指标均为 0~1；和论文百分数对比时乘 100。OVO 相对 OVR 的增长率定义为 `(OVO/OVR - 1)*100%`；OVR 为 0 时该增长率无定义，不能替换成 0。
- 原始预测中的 `y_true/y_pred` 是从 0 开始的整数编码，类别名称映射见各 JSON 的 `class_labels`。和其他人的混淆矩阵对比前，要先统一真实类别名称与排序。

## 已完成的核查

- 102 个结果 JSON、102 个配套预测 CSV，全部组合和五折均齐全。
- 510 个折、4080 次学习率试验，合计核对 97785 条逐 epoch 记录。
- 预测对每个数据集的样本覆盖恰好一次，无重复/缺失；真实标签和 fold 归属与当前原始数据及划分代码一致。
- 数据指纹与报告一致；训练/验证/测试数量、选参历史、最佳 epoch、早停和重训参数一致。
- 从预测文件的混淆矩阵独立重算四个指标，分别与每折及合并结果匹配（数值容差 1e-10）；未发现缺失、非有限值或内部不一致。
- 全部报告使用 CUDA、seed=42、batch size=8、max_epochs=40、patience=10、8 个论文学习率。

35 组结果的 G-mean 为 0，表示至少一个类别 recall=0；这不是结果文件缺失。

## 结果解读与复现约定

文件完整、指标一致不表示已复现出与论文相同的数值或趋势。这次运行中，Macro-F1 选参时，OVR 的平均 Macro-F1 为 74.20%，OVO 为 72.88%；Accuracy 选参时分别为 71.68% 和 70.26%。请保留这些实际结果，不要为了贴合论文结论而筛选数据集或混用选参标准。

当前结果是一组 seed=42 的运行。完整训练分区的重训轮数采用内层验证选中的最佳 epoch，这是对论文未明确重训早停方式的实现约定。Adam 使用默认 betas=(0.9,0.999)、eps=1e-8、weight_decay=0。极少数类在部分内层分区中可能缺失；指标显式包含全部类别，零分母按 0 处理。这些设置需要在项目报告中交代。

## 复现具体划分或重做核查

`reproducibility/` 保存本次代码及数据登记表快照，不包含原始数据和 Python 环境。组员通常可直接在共享项目中使用这些代码。另附 `environment_checked.json` 记录核查时的依赖版本；各 JSON 的 `split_config` 记录划分依赖版本和数据指纹。

在原项目根目录，示例：

```powershell
.\.venv\Scripts\python.exe -m src.network.reproduce_split --report results/neural_network_skorch/CAR_ovo_macro_f1_folds12345_seed42.json --fold 1
.\.venv\Scripts\python.exe -m src.network.check_results
```

换电脑时应使用相同原始数据和划分代码，必要时通过 `--data-dir` 指向对应目录。JSON 中的原机器绝对路径不要求相同，数据指纹和版本应一致。样本 `sample_index` 是 `load_dataset` 返回的行位置，不是原始数据文件的行号。

模型权重未由原训练脚本保存，本包没有 `.pt`；做指标对比不需要模型权重，保留原始预测即可。
