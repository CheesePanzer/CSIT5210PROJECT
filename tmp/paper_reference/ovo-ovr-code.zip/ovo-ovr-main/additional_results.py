import os
import json
import pandas as pd
from ovo_ovr_utils import parse_decision_val, ovo2ovr_decision

data2ir = {
    'aut': 16.0 ,
    'bal': 5.88 ,
    'car': 18.62,
    'cle': 12.31,
    'der': 5.55 ,
    'eco': 71.5 ,
    'fla': 7.7  , 
    'gla': 8.44 , 
    'hay': 2.1  , 
    'hcv': 75.14,
    'lym': 40.5 , 
    'new': 5.0  , 
    'seg': 1    ,
    'shu': 853.0,
    'thy': 39.18, 
    'veh': 1.1  ,
    'zoo': 10.25
}

def ir_group(ir):
    if ir < 3:
        return 'low'
    elif ir < 9:
        return 'medium'
    else:
        return 'high'
    
def metric_under_imbalance_group(df):
    df['IR'] = df.index.map(data2ir)
    df['GROUP'] = df['IR'].apply(ir_group)
    results = df.loc[df.index!='Average'].groupby('GROUP').mean().round(2)
    return results.loc[['low', 'medium', 'high']]

def generate_confusion_matrix(dataset_name, model, monitor):
    dataset_ouputs = json.load(open(os.path.join('results', model, 'dataset_ouputs.json'), 'r'))
    crosstab_dict = {}
    for train_method in ["one-vesrus-rest", "one-vesrus-one"]:
        target = dataset_ouputs[monitor][train_method][dataset_name]['target']

        if (model == 'svm') and (train_method == "one-vesrus-one"):
            decision_val = dataset_ouputs[monitor][train_method][dataset_name]['decision_val']
            label_orders, decision_dict, decision_dict_converted = parse_decision_val(decision_val)
            decision_ovr = ovo2ovr_decision(decision_dict_converted, len(set(target)))
            predict = decision_ovr.argmax(axis=1) + 1
        else:
            predict = dataset_ouputs[monitor][train_method][dataset_name]['predict']

        table = pd.DataFrame({
            'target': target,
            'predict': predict
        })
        crosstab = pd.crosstab(table['target'], table['predict'])
        crosstab['Total'] = crosstab.sum(axis=1)
        crosstab_dict[train_method] = crosstab.T
    return pd.concat(crosstab_dict, axis=1)


if __name__ == "__main__":

    models = ['svm', 'NN']
    monitors = ['Accuracy', 'MacroF1']

    for model in ['svm', 'NN']:
        dest_dir = os.path.join('results', model)
        for monitor in monitors:
            metric = pd.read_csv(os.path.join(dest_dir, f'{monitor}.csv'), header=[0, 1], index_col=0)
            group_df = metric_under_imbalance_group(metric)
            group_df.to_csv(os.path.join(dest_dir, f'{monitor}_under_imbalance_group.csv'))

    # if you want to check confusion matrix
    model = 'NN'
    monitor = 'MacroF1'
    dataset_name = 'shuttle'

    cm = generate_confusion_matrix(dataset_name, model, monitor)



