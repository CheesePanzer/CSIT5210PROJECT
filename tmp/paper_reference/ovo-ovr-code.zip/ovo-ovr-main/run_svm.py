import os
import re
import json
import numpy as np
from tqdm.auto import tqdm
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import accuracy_score

from libmultilabel.linear.metrics import F1
os.sys.path.append('./libsvm/python')
from libsvm.svmutil import svm_read_problem, svm_train, svm_predict
os.sys.path.append('./libsvm/tools')
from grid import find_parameters

def generate_configs(c_options, g_options):
    configs = []
    for c in c_options:
        for g in g_options:
            # we always use RBF kernel (-t 2)
            configs.append(f"-c {c} -t 2 -g {g}") 
    return configs

# create libsvm format file for training and testing set
def dump_svm_format(all_x, all_y, train_indicies, fold_idx):
    out_tmp_train_fold = open(f"out_tmp_train_fold_{fold_idx}.svm", "w")
    out_tmp_test_fold = open(f"out_tmp_test_fold_{fold_idx}.svm", "w")
    for i in range(len(all_x)):
        tmp_x = sorted([f'{k}:{v}'for k, v in all_x[i].items()], key=lambda x: int(x.split(':')[0]))
        tmp_x = ' '.join(tmp_x)
        tmp_y = int(all_y[i])
        line = f'{tmp_y} {tmp_x}\n'
        if i in train_indicies: 
            out_tmp_train_fold.write(line)
        else:
            out_tmp_test_fold.write(line)
    out_tmp_train_fold.close()
    out_tmp_test_fold.close()
    return 

# get monitored metric
def get_metrics(predict, target):
    num_samples = len(predict)
    num_classes = len(set(target))

    f1_macro = F1(num_classes=num_classes, average="macro", multiclass=True)

    predict_arr = np.zeros((num_samples, num_classes))
    predict_arr[np.arange(num_samples), np.array(predict, dtype=int)-1] = 1

    target_arr = np.zeros((num_samples, num_classes))
    target_arr[np.arange(num_samples), np.array(target, dtype=int)-1] = 1

    f1_macro.update(predict_arr, target_arr)

    macroF = round(f1_macro.compute() * 100, 2)
    acc = round(accuracy_score(target, predict) * 100, 2)
    gmean = np.exp(np.log(f1_macro.tp / (f1_macro.tp + f1_macro.fn)).mean())

    metrics = {
        '-Accuracy': acc,
        '-MacroF1': macroF,
        '-Gmean': gmean
    }
    return metrics

# run one scv for given x, y for one versus rest
def run_one_scv(config, train_x, train_y):

    target = []
    predict = []
    scv5 = StratifiedKFold(n_splits=5)
    for fold_idx, (train_index, test_index) in enumerate(scv5.split(train_x, train_y), 1):
        dump_svm_format(train_x, train_y, train_index, fold_idx)

        cmd = f'./binary.py {config} out_tmp_train_fold_{fold_idx}.svm out_tmp_test_fold_{fold_idx}.svm'
        os.system(cmd)
        
        label_file = os.path.join('ovr-predict', 'tmp', f'out_tmp_test_fold_{fold_idx} label.json') 
        with open(label_file, 'r') as f:
            label_info = json.load(f)

        target.extend(label_info['target'])
        predict.extend(label_info['predict'])

        os.system(f'rm "{label_file}" || true')
        os.system(f'rm out_tmp_train_fold_{fold_idx}.svm out_tmp_test_fold_{fold_idx}.svm')

    assert len(target) == len(predict)
    assert len(target) == len(train_x)

    metrics = get_metrics(predict, target)
    return metrics

def find_best_parameters(train_file, search_configs=[], monitor='-Accuracy'):
	
    best_rate, best_param = 0, {}
    for search_config in search_configs: 
        search_arg = f'{search_config} -gnuplot null {monitor}'
		
        rate, param = find_parameters(train_file, search_arg)

        # add -t into param 
        param['t'] = 2

        if '-M 0' in search_arg:
            param['M'] = 0
        elif '-M 1' in search_arg:
            param['M'] = 1
        
        # update best param
        if rate >= best_rate:
            best_rate = rate
            best_param = param

    return best_rate, best_param

def run_ovr(datasets, configs, monitor='-Accuracy'):
    for dataset_name in tqdm(datasets):
        
        save_dir = os.path.join(f'svm-predict{monitor}', dataset_name, 'one-vesrus-rest')
        os.makedirs(save_dir, exist_ok=True)
        
        # tmp folder
        tmp_dir = os.path.join('ovr-predict', dataset_name)
        os.system(f'rm -r {tmp_dir}')
        os.makedirs(tmp_dir, exist_ok=True)

        for i in range(1, 6):

            grid_search_results = open(os.path.join(save_dir, f'train_{dataset_name}_{i}.svm.out'), "w")
    
            train_file = os.path.join('svm_data', dataset_name, f'train_{dataset_name}_{i}.svm')
            test_file = os.path.join('svm_data', dataset_name, f'test_{dataset_name}_{i}.svm')
            
            best_config = None
            best_rate = 0
            # Read data in LIBSVM format
            trainY, trainX = svm_read_problem(train_file) 

            for config in configs:
                metrics = run_one_scv(config, trainX, trainY)
                c, g = re.findall(r'-(?:c|g)\s([+-]?\d+(?:\.\d+)?)', config)
                one_trial_result = f"log2c={np.log2(float(c))} log2g={np.log2(float(g))} rate={metrics[monitor]}\n"
                grid_search_results.write(one_trial_result)
            
                if metrics[monitor] > best_rate:
                    best_rate = metrics[monitor]
                    best_config = config

            grid_search_results.close()
            # retrain cmd for one vesus rest
            cmd = f'./binary.py {best_config} {train_file} {test_file}'
            os.system(cmd)
        os.system(f'mv ovr-predict/{dataset_name}/*.json {save_dir}')
        os.system('rm -r ovr-predict')
        os.system('rm -r tmp_*')
    return

def run_ovo(datasets, search_configs=['-log2c -2,12,1 -log2g -10,4,1 -t 2'], monitor='-Accuracy'):
    for dataset_name in tqdm(datasets):

        save_dir = os.path.join(f'svm-predict{monitor}', dataset_name, 'one-vesrus-one')
        os.system(f'rm -r {save_dir}')
        os.makedirs(save_dir, exist_ok=True)

        for i in range(1, 6):
            train_file = os.path.join('svm_data', dataset_name, f'train_{dataset_name}_{i}.svm')
            test_file = os.path.join('svm_data', dataset_name, f'test_{dataset_name}_{i}.svm')

            best_rate, best_param = find_best_parameters(train_file,
                                                        search_configs,
                                                        monitor)

            if 'g' in best_param:
                config =  f"-c {best_param['c']:.1f} -t {best_param['t']} -g {best_param['g']:.6g}"
            elif 't' in best_param :
                config =  f"-c {best_param['c']:.1f} -t {best_param['t']}"
            else:
                config =  f"-c {best_param['c']:.1f}"

            # train model by using 80% data and predict
            # Read data in LIBSVM format
            trainY, trainX = svm_read_problem(train_file) 
            
            m = svm_train(trainY, trainX, config)
            
            # predict
            testY, testX = svm_read_problem(test_file) 
            p_label, p_acc, p_val = svm_predict(testY, testX, m)

            decision_val = []
            nr_class = m.get_nr_class()
            model_labels = m.get_labels()
            for one_dec_val in p_val:
                dec_str = ['$'.join(map(str, model_labels))]
                p = 0
                for i in range(nr_class):
                    for j in range(i + 1, nr_class):

                        raw_one_dec_val = one_dec_val[p]
                        dec_str.append(f'{p+1}:{raw_one_dec_val}')
                        p += 1
                
                decision_val.append(','.join(dec_str))

            label_info = {
                'target': testY, 
                'predict': p_label,
                'decision_val': decision_val,
                'config': [config]
            }

            file_name = os.path.basename(test_file).split('.')[0]
            label_file = os.path.join(f'svm-predict{monitor}', dataset_name, 'one-vesrus-one', f'{file_name} label.json') 
            os.system(f"mv *.out {save_dir}")

            with open(label_file, 'w') as f:
                json.dump(label_info, f, indent=4)
    return



if __name__ == "__main__":
    c_options = 2.**np.arange(-2, 13, 1)
    g_options = 2.**np.arange(-10, 5, 1) 

    configs = generate_configs(c_options, g_options)
    search_configs = ['-log2c -2,12,1 -log2g -10,4,1 -t 2']

    datasets = ['autos', 'balance', 'car', 'cleveland', 'dermatology', 'ecoli', 'flare', 'glass', 'hayes-roth', 'hcv', 'lymphography', 'newthyroid', 'segment', 'shuttle', 'thyroid', 'zoo', "vehicle"]

    for monitor in ['-Accuracy', '-MacroF1']:
        run_ovr(datasets, configs, monitor)
        run_ovo(datasets, search_configs, monitor)