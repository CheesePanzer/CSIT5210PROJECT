import numpy as np

c_options = 2.**np.arange(-2, 13, 1)
g_options = 2.**np.arange(-10, 5, 1) 

def generate_configs(c_options, g_options):
    configs = []
    for c in c_options:
        for g in g_options:
            # we always use RBF kernel (-t 2)
            configs.append(f"-c {c} -t 2 -g {g}") 
    return configs

print(generate_configs(c_options, g_options))