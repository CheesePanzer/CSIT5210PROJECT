#!/usr/bin/env python3

import sys, os.path
from sys import argv
from os import system, remove
from string import *
from subr import *
import json

global train, test, pass_through_options
global labels, features, test_labels

svmtrain_exe = os.path.join('libsvm', 'svm-train')
svmpredict_exe = os.path.join('libsvm', 'svm-predict')

# process command line options, set global parameters
def process_options(argv = sys.argv):
	global train, test, pass_through_options

	if len(argv) < 3:
		print("Usage: %s [parameters for svm-train] training_file test_file".format(argv[0]))
		sys.exit(1)

	train = argv[-2]
	test = argv[-1]

	assert os.path.exists(train), "training_file not found."
	assert os.path.exists(test), "test_file not found."

	pass_through_options = " ".join(argv[1:len(argv)-2])

def read_problem(file):
	assert os.path.exists(file), "%s not found." % (file)

	_labels = []
	_features = []

	in_file = open(file, "r")
	for line in in_file:
		spline = line.split()
		if spline[0].find(':') == -1:
			_labels.append(spline[0].split(','))
			_features.append(' '.join(spline[1:]))
		else:
			_labels.append([])
			_features.append(' '.join(spline))
	in_file.close()

	return (_labels, _features)

def count_labels(labels):
	_labels = []

	for i in range(len(labels)):
		for lab in labels[i]:
			if (lab not in _labels):
				_labels.append(lab)

	return _labels

# Give me a label
def build_problem(lab):
	# build binary classification problem for label lab
	problem = open("tmp_binary", "w")

	for t in range(len(labels)):
		if lab in labels[t]:
			problem.write("+1 {}\n".format(features[t]))
		else:
			problem.write("-1 {}\n".format(features[t]))

	problem.close()

def train_problem(lab):
	print("Training problem for label {}...".format(lab))

	cmd = "%s %s %s %s" % (svmtrain_exe, pass_through_options, "tmp_binary", "tmp_model")
	os.system(cmd)

def test_problem(lab):
	print("Testing problem for label {}...".format(lab))
	
	prob_estimate = ' -b 1 ' if '-b 1' in pass_through_options else ' '
	cmd = "%s%s%s %s %s" % (svmpredict_exe, prob_estimate, "tmp_test", "tmp_model", "tmp_output")
	os.system(cmd + '> tmp_log')

def build_test(testset):
	global test_labels

	(test_labels, x) = read_problem(testset)
	out_test = open("tmp_test", "w")
	for i in range(len(test_labels)):
		out_test.write("+1 %s\n" % x[i])
	out_test.close()

def get_output(lab):
	index = []

	# output = open("tmp_output", "r");
	output = open("tmp_log", "r");
	t = 0
	# t = -1
	for line in output:
		# if line.split('\n')[0] == "1":
		# 	index.append(t)
		# if not line.startswith('labels'):
		# 	# index.append((t, line.split(' ')[1]))
		# 	index.append((t, line.strip()))		
		if line.startswith('decision value log: '):
			index.append((t, line.split('decision value log: ')[1].strip()))

		t = t + 1

	output.close()

	return index

def main():
	global train, test
	global labels, features, test_labels

	process_options()

	# read problem and get all labels
	(labels, features) = read_problem(train)
	all_labels = count_labels(labels)

	build_test(test)

	predict = []
	for i in range(len(test_labels)):
		predict.append([])

	for i in range(len(all_labels)):
		# train binary problem for the label all_labels[i]
		lab = all_labels[i] 

		build_problem(lab)
		train_problem(lab)
		test_problem(lab)
		index = get_output(lab)
		for idx in index:
			predict[idx[0]].append("%s:%s" % (lab, idx[1]))

	decision_val = []
	out_predict = open("tmp_predict", "w")
	for i in range(len(predict)):
		decision_val_one = "%s\n" % ",".join(predict[i])
		out_predict.write(decision_val_one)
		decision_val.append(decision_val_one.strip())
	out_predict.close()
	
	for i in range(len(predict)):
		predict[i] = [sorted(predict[i], key=lambda x: float(x.split(':')[1]), reverse=True)[0].split(':')[0]]


	label_info = {
		'target': [int(i[0]) for i in test_labels], 
		'predict': [int(i[0]) for i in predict], 
		'decision_val': decision_val,
		'config': [pass_through_options]
	}
	dataset_name = os.path.basename(train).split('_')[1]
	os.makedirs(os.path.join('ovr-predict', dataset_name), exist_ok=True)
	file_name = os.path.basename(test).split('.')[0]
	file_dir = os.path.join('ovr-predict', dataset_name, f'{file_name} label.json')
	print(file_dir)
	with open(file_dir, 'w') as file:
		json.dump(label_info, file, indent=4)

	result = measure(test_labels, predict, all_labels)

	print("Exact match ratio: {:.2f}".format(result[0]))
	print("Microaverage F-measure: {:.2f}".format(result[1]))
	print("Macroaverage F-measure: {:.2f}".format(result[2]))

	sys.stdout.flush()

main()
