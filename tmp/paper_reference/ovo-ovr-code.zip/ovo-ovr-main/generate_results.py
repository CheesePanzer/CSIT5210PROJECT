import os
import json
import glob
import numpy as np
import pandas as pd
from tqdm.auto import tqdm
from collections import defaultdict
from sklearn.metrics import accuracy_score, balanced_accuracy_score, roc_auc_score

from ovo_ovr_utils import parse_decision_val, ovo2ovr_decision, gen_label_vector

from libmultilabel.linear.metrics import F1

def sigmoid(x):
    return np.where(
        x >= 0, # condition
        1 / (1 + np.exp(-x)), # For positive values
        np.exp(x) / (1 + np.exp(x)) # For negative values
    )

def softmax(x):
    """Compute softmax values for each set of scores in x."""
    # Subtract the max value in each row for numerical stability
    x_max = np.max(x, axis=1, keepdims=True)
    exp_x = np.exp(x - x_max)
    return exp_x / np.sum(exp_x, axis=1, keepdims=True)

# get monitored metric
def get_metrics(predict, target, decision_val=None, ovo2ovr=False):
    num_samples = len(predict)
    num_classes = len(set(target))

    f1_macro = F1(num_classes=num_classes, average="macro", multiclass=True)

    predict_arr = np.zeros((num_samples, num_classes))
    predict_arr[np.arange(num_samples), np.array(predict, dtype=int)-1] = 1

    target_arr = np.zeros((num_samples, num_classes))
    target_arr[np.arange(num_samples), np.array(target, dtype=int)-1] = 1

    f1_macro.update(predict_arr, target_arr)

    macroF = round(f1_macro.compute() * 100, 2)
    acc = round(accuracy_score(target, predict) * 100, 2)
    gmean = round(np.exp(np.log(f1_macro.tp / (f1_macro.tp + f1_macro.fn)).mean()) * 100, 2)
    bal_acc = round(balanced_accuracy_score(target, predict) * 100, 2) 

    metrics = {
        '-Accuracy': acc,
        '-MacroF1': macroF,
        '-Gmean': gmean,
        '-BalancedAccuracy': bal_acc,
    }

    ovo_auc = -999
    if (decision_val is not None) and ('NA' not in decision_val) :
        if isinstance(decision_val[0], list):
            d = []
            for batch in decision_val:
                d.extend(batch)
            decision_val = d
        label_orders, decision_dict, decision_dict_converted = parse_decision_val(decision_val)
        # if len(decision_dict) == num_classes: # can use this beacuse #classifiers are the same when #class = 3
        # OVR because we dont store label orders for OVR
        if len(label_orders) == 0:
            decision_arr = np.vstack([decision_dict[k] for k in sorted(decision_dict.keys(), key=int)]).T
            ovo_auc = round(roc_auc_score(target, softmax(decision_arr), multi_class='ovo') * 100, 2) 
            
        else:
            label_vector = gen_label_vector(np.array(target), label_orders, num_classes, 'one-vesrus-one')
            ovo_auc = np.zeros(label_vector.shape[1])
            for label_idx in range(label_vector.shape[1]):
                one_label_vector = label_vector[:,label_idx]
                valid_instance_idx = one_label_vector != -1
                pairwise_decision = decision_dict[str(label_idx+1)] 
                ovo_auc[label_idx] = roc_auc_score(one_label_vector[valid_instance_idx], pairwise_decision[valid_instance_idx])
            ovo_auc = round(ovo_auc.mean() * 100, 2)

        if ovo2ovr:
            decision_ovr = ovo2ovr_decision(decision_dict_converted, num_classes)
            predict = decision_ovr.argmax(axis=1) + 1
            metrics = get_metrics(predict, target, decision_val=None, ovo2ovr=False)

    metrics['-OVOAUC'] = ovo_auc
    # print(metrics)
    return metrics

def load_model_results(datasets, train_methods, monitors, model):
    dataset_ouputs = defaultdict(lambda: defaultdict(lambda: defaultdict(lambda: defaultdict(list))))
    for dataset_name in tqdm(datasets):
        for monitor in monitors: 
            for train_method in train_methods:    
                # if train_method == 'ovo-weight':
                #     dataset_ouputs[monitor][train_method][dataset_name] = ["follow ovo"]
                # if (train_method in ["cross-entropy", "one-vesrus-rest", "one-vesrus-one"]) and (monitor not in ['TabPFN', 'NN-Accuracy', 'NN-MacroF1', 'NN-Loss']):
                #     continue

                model_result_dir = os.path.join(f'{model}-predict-{monitor}', dataset_name, train_method) 
                print(model_result_dir)
                for label_file in sorted(glob.glob(os.path.join(model_result_dir, '*.json'))):
                    label_info = json.load(open(label_file, 'r'))
                    for k, v in label_info.items():
                    
                        if k in ['target', 'predict']:
                            v = [int(i) for i in v]
                        dataset_ouputs[monitor][train_method][dataset_name][k].extend(v) 
            # sanity check
            for m in train_methods:
                if ('one-vesrus-rest' == m) and (m.replace('one-vesrus-rest', 'one-vesrus-one') in train_methods): 
                    assert all([
                        a == b for (a, b) in zip(
                            dataset_ouputs[monitor][m.replace('one-vesrus-rest', 'one-vesrus-one')][dataset_name]['target'],
                            dataset_ouputs[monitor][m][dataset_name]['target']
                        )
                    ])
            
    return dataset_ouputs

def generate_metrics(dataset_ouputs, model, use_prefix3=True):
    dataset_metrics = defaultdict(lambda: defaultdict(lambda: defaultdict(list)))
    metric_df = defaultdict(lambda: defaultdict(dict))
    for monitor in dataset_ouputs.keys(): 
        for train_method in dataset_ouputs[monitor].keys():     
            for dataset_name in tqdm(dataset_ouputs[monitor][train_method].keys()):
                if (model == 'svm') and (train_method == "one-vesrus-one"):
                    # since in svm, ovo method generate #class * (#class-1) decision values
                    # we convert them into ovr decision values for evaluation
                    ovo2ovr = True
                else:
                    ovo2ovr = False
                metrics = get_metrics(predict=dataset_ouputs[monitor][train_method][dataset_name]["predict"],
                                    target=dataset_ouputs[monitor][train_method][dataset_name]["target"],
                                    decision_val=dataset_ouputs[monitor][train_method][dataset_name]["decision_val"],
                                    ovo2ovr=ovo2ovr)
                
                metric_info = [metrics['-MacroF1'], metrics['-Gmean'], metrics['-Accuracy'], metrics['-BalancedAccuracy'], metrics['-OVOAUC']]
                if use_prefix3:
                    dataset_metrics[monitor][train_method][dataset_name[:3]]= metric_info
                else:
                    dataset_metrics[monitor][train_method][dataset_name]= metric_info

            metric_df[monitor][train_method] = pd.DataFrame(dataset_metrics[monitor][train_method], index=['MacroF1', 'Gmean', 'Accuracy', 'BalancedAccuracy', 'OVOAUC']).T

        metric_df[monitor] = pd.concat(metric_df[monitor], axis=1)
        metric_df[monitor].columns = metric_df[monitor].columns.swaplevel(0, 1)
        metric_df[monitor] = metric_df[monitor].reindex(columns=['Accuracy', 'MacroF1', 'Gmean', 'BalancedAccuracy', 'OVOAUC'], level=0)
        metric_df[monitor].loc['Average'] = metric_df[monitor].mean()
        metric_df[monitor] = metric_df[monitor].round(2)

    return metric_df, dataset_metrics

if __name__ == "__main__":

    datasets = ['autos', 'balance', 'car', 'cleveland', 'dermatology', 'ecoli', 'flare', 'glass', 'hayes-roth', 'hcv', 'lymphography', 'newthyroid', 'segment', 'shuttle', 'thyroid', 'vehicle', 'zoo']
    models = ['svm', 'NN']
    monitors = ['Accuracy', 'MacroF1']

    for model in models:
        if model == 'svm':
            train_methods = ["one-vesrus-rest", "one-vesrus-one"]
        else:
            train_methods = ["cross-entropy", "one-vesrus-rest", "one-vesrus-one"]

        dataset_ouputs = load_model_results(datasets, train_methods, monitors, model)
        metric_df, dataset_metrics = generate_metrics(dataset_ouputs, model)

        dest_dir = os.path.join('results', model)
        os.makedirs(dest_dir, exist_ok=True)
        json.dump(dataset_ouputs, open(os.path.join(dest_dir, 'dataset_ouputs.json'), 'w'), indent=4)
        json.dump(dataset_metrics, open(os.path.join(dest_dir, 'dataset_metrics.json'), 'w'), indent=4)
        for monitor in metric_df.keys():
            metric_df[monitor].to_csv(os.path.join(dest_dir, f'{monitor}.csv'))
