# [ICDM 2025] *Revisiting One-Versus-One and One-Versus-Rest: Insights into Imbalanced Multi-class Classification*

This repository provides the code to reproduce the experiments in our paper.  
It includes environment setup, dataset preparation, model training (Kernel SVM and Neural Network), and result generation.

---

## Setup Environment
Create the required environment using:
```bash
bash build_env.sh
```

## Download Datasets
Download all datasets (KEEL dataset, LIBSVM dataset, and UCI dataset) with:
```bash
bash get_data.sh
# Files will be stored in raw_data/
```

## Preprocess Datasets
Convert datasets into LIBSVM format and generate stratified 5-fold splits.
For datasets without stratified 5-fold splits (including some LIBSVM datasets and UCI datasets), stratified splitting is performed to preserve label distribution.

```bash
bash process_data.sh
# Files will be stored in svm_data/
```

## Train Kernel SVM (OVO and OVR)
Run training with LIBSVM for one-vs-one and one-vs-rest:
```python
python3 run_svm.py
```

## Train Neural Network (OVO and OVR)
Run training with Neural Networks (including cross-entropy loss).
Modules for NN training are in the folder `multi_class_nn`.

```python
python3 run_nn.py
```

## Run All Experiments
Run both Kernel SVM and Neural Network training:
```bash
bash run_ovo_ovr.sh
```

## Generate Results
Collect and summarize the performance (OVO and OVR) for each dataset:
```python
python generate_results.py
# Results will be saved under results/
```
You can use the following code to read the results:
```python
model = "svm" # or "NN"
monitor = "Accuracy" # or "MacroF1"
metric = pd.read_csv(os.path.join('results', model, f'{monitor}.csv'), header=[0, 1], index_col=0)
```

## Additional Results
The paper also presents extended analyses, which can be reproduced using additional evaluation scripts:

- Performance across imbalance groups:
Evaluate OVO and OVR performance under different imbalance levels, grouping classes by their imbalance ratio.

- Confusion matrices:
Generate confusion matrices to visualize misclassification patterns and compare how OVO and OVR handle minority vs majority classes.
```python
python3 additional_results.py
# Results will be saved under results/
```