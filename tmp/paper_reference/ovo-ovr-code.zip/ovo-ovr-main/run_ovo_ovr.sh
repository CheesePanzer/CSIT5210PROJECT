python3 run_svm.py
python3 run_nn.py
