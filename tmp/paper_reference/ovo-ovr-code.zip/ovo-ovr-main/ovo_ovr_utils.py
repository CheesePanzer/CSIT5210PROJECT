import numpy as np
from collections import defaultdict
from sklearn.utils.multiclass import _ovr_decision_function

def ovo_class_vector(n_class):
    vec_dim = n_class * (n_class-1) // 2
    class_vector = np.full((n_class, vec_dim), -1, dtype=int)

    for label in range(n_class):
        p = 0  # position in label_vector
        for i in range(0, n_class):
            for j in range(i+1, n_class):
                if label == i:
                    class_vector[label,p] = 1
                elif label == j:
                    class_vector[label,p] = 0
                p += 1
    return class_vector

def gen_label_vector(labels, label_orders, n_class, train_method='one-vesrus-one'):
    
    n = len(labels)
    if 'one-vesrus-rest' == train_method:
        label_vector = np.zeros((n, n_class))
        label_vector[range(n), labels-1] = 1 # labels starts from 1
    else:
        class_vector = ovo_class_vector(n_class)
        sorted_indices = np.argsort(label_orders, axis=1)
        converted_indices = sorted_indices[range(n), labels-1] # labels starts from 1
        label_vector = class_vector[converted_indices] 

    return label_vector

def gen_idx2pair_dict(label_order):
    nr_class = len(label_order)
    idx2pair = dict()
    p = 1
    for i in range(nr_class) :
        for j in range(i + 1, nr_class):
            idx2pair[str(p)] = (label_order[i], label_order[j])
            p += 1

    return idx2pair

def parse_decision_val(decision_val_list):
    
    decision_dict = defaultdict(list)
    decision_dict_converted = defaultdict(list)
    label_orders = []
    train_method = 'one-vesrus-rest'
    for decision_one in decision_val_list:
        
        for val in decision_one.split(','):
            
            # first element of raw, only one-vesrus-one we store label order
            if '$' in val:
                label_order = val.split('$')
                label_orders.append(label_order)
                
                train_method = 'one-vesrus-one'
                idx2pair = gen_idx2pair_dict(label_order)

            # the remaining element
            else:
                idx, val = val.split(':')
                val = float(val)
                if train_method == 'one-vesrus-one':
                    i, j = idx2pair[idx]
                    if i > j:
                        i, j = j, i
                        decision_dict_converted[f'{i}vs{j}'].append(-1 * val) #change the direction 
                    else:
                        decision_dict_converted[f'{i}vs{j}'].append(val)
                else:
                    decision_dict_converted[idx].append(val)

                decision_dict[idx].append(val)

    for label, decision_val in decision_dict.items():
        decision_dict[label] = np.array(decision_val)
    
    for label, decision_val in decision_dict_converted.items():
        decision_dict_converted[label] = np.array(decision_val)

    label_orders = np.array(label_orders, dtype=int)
    return label_orders, decision_dict, decision_dict_converted

def ovo2ovr_decision(decision_dict_converted, n_classes):
    decision_arr = np.vstack([
        decision_dict_converted[k] for k in sorted(
            decision_dict_converted.keys(), key=lambda x: list(map(int, x.split('vs')))
        )
    ]).T
    # sklearn predict 1 if f(a) < f(b), 0 if f(a) >= f(b)
    decision_ovr = _ovr_decision_function(decision_arr<=0, -decision_arr, n_classes=n_classes)
    return decision_ovr