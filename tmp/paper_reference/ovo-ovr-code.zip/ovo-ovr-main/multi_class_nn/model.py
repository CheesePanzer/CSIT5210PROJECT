import torch
import torch.nn as nn

class FeedforwardNN(nn.Module):
    def __init__(self, input_size, output_size=1, dropout_rate=0.1):
        super(FeedforwardNN, self).__init__()
        self.output_size = output_size
        self.fc = nn.Sequential(
            nn.Linear(input_size, 128),
            nn.LayerNorm(128), 
            nn.ReLU(),
            nn.Dropout(dropout_rate),
            nn.Linear(128, 64),
            nn.LayerNorm(64),   
            nn.ReLU(),
            nn.Linear(64, output_size)  
        )

    def forward(self, x):
        return self.fc(x)
