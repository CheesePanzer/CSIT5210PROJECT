import torch
import numpy as np
import torch.nn as nn
import torch.nn.functional as F

class OneVersusRestLoss(nn.Module):
    def __init__(self):
        super(OneVersusRestLoss, self).__init__()
        self.binary_loss_function = nn.BCELoss()

    def forward(self, logits, target):
        prob = F.softmax(logits, dim=1)
        binary_target = torch.zeros_like(prob).to(prob.device)
        binary_target[np.arange(len(target)), target] = 1
        ovr_loss = self.binary_loss_function(prob, binary_target)

        return ovr_loss

class OneVersusOneLoss(nn.Module):
    def __init__(self, num_classes, binary_loss_function="binary_cross_entropy_with_logits"):
        super(OneVersusOneLoss, self).__init__()
        self.num_classes = num_classes
        self.scale = self.num_classes * (self.num_classes-1) / 2
        assert hasattr(
            F, binary_loss_function
        ), """
            Invalid `binary_loss_function`. Make sure the loss function is defined here:
            https://pytorch.org/docs/stable/nn.functional.html#loss-functions"""
        self.binary_loss_function = getattr(F, binary_loss_function)

    def forward(self, logits, target):

        mask = torch.arange(self.num_classes).unsqueeze(0).to(target.device) == target.unsqueeze(1)
        occurrence = mask.sum(dim=0).repeat(target.size(0), 1)
        relative_confidence = logits[mask].unsqueeze(1) - logits[~mask].view(-1, self.num_classes-1)
        occurrence_ij = occurrence[mask].unsqueeze(1) + occurrence[~mask].view(-1, self.num_classes-1)

        ovo_loss = -1 * (F.logsigmoid(relative_confidence) / occurrence_ij).sum()
        ovo_loss /= self.scale

        return ovo_loss