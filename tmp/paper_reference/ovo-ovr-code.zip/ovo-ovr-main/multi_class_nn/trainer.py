import os
import torch
import torch.optim as optim
import numpy as np
from torch.utils.data import DataLoader

from .model import FeedforwardNN
from .evaluation import evaluate_model
from .data_utils import set_seed, stratified_split
from .ovo_loss import OneVersusRestLoss, OneVersusOneLoss
# Core training function with validation
def train_model(model, train_loader, val_loader, method, learning_rate, epochs, patience, stop_criteria, save_path, device=None):
    if device is None:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    if method == "cross-entropy":
        criterion = torch.nn.CrossEntropyLoss() 
    elif method == "one-vesrus-rest":
        criterion = OneVersusRestLoss() 
    elif method == "one-vesrus-one":
        criterion = OneVersusOneLoss(num_classes=model.output_size, binary_loss_function="binary_cross_entropy_with_logits")
    else:
        raise Exception('method should be in ["cross-entropy", "one-vesrus-rest", "one-vesrus-one"]')

    optimizer = optim.Adam(model.parameters(), lr=learning_rate)

    best_metric = -1 * np.inf
    best_epoch = 0
    wait = 0

    for epoch in range(epochs):
        model.train()
        total_loss = 0
        for inputs, labels in train_loader:
            inputs, labels = inputs.to(device), labels.to(device)

            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            total_loss += loss.item()

        if val_loader is not None:
            val_metric = evaluate_model(model, val_loader, criterion, stop_criteria, device)
            print(f"Epoch {epoch + 1}/{epochs}, Loss: {total_loss / len(train_loader):.4f}, Validation {stop_criteria}: {val_metric:.4f}")

            if val_metric >= best_metric:
                best_metric = val_metric
                best_epoch = epoch + 1 #epoch start from zero
                wait = 0
                torch.save(model.state_dict(), save_path)
            else:
                wait += 1

            if wait >= patience:
                print("Early stopping triggered.")
                break
        else:
            print(f"Epoch {epoch + 1}/{epochs}, Loss: {total_loss / len(train_loader):.4f}")
            if epoch == epochs - 1:
                torch.save(model.state_dict(), save_path)

    return best_epoch, best_metric

# # Function to retrain with the full training dataset
# def retrain_model(model, full_train_loader, method, learning_rate, best_epoch, save_path="retrain.pth", device=None):
#     if device is None:
#         device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

#     if method == "cross-entropy":
#         criterion = torch.nn.CrossEntropyLoss() 
#     elif method == "one-vesrus-rest":
#         criterion = OneVersusRestLoss() 
#     elif method == "one-vesrus-one":
#         criterion = OneVersusOneLoss(num_classes=model.output_size, binary_loss_function="binary_cross_entropy_with_logits")
#     else:
#         raise Exception('method should be in ["cross-entropy", "one-vesrus-rest", "one-vesrus-one"]')
    
#     optimizer = optim.Adam(model.parameters(), lr=learning_rate)
    
#     model.train()
#     for epoch in range(best_epoch):
#         total_loss = 0
#         for inputs, labels in full_train_loader:
#             inputs, labels = inputs.to(device), labels.to(device)

#             optimizer.zero_grad()
#             outputs = model(inputs)
#             loss = criterion(outputs, labels)
#             loss.backward()
#             optimizer.step()

#             total_loss += loss.item()
#         print(f"Retrain Epoch {epoch + 1}/{best_epoch}, Loss: {total_loss / len(full_train_loader):.4f}")
#     torch.save(model.state_dict(), save_path)
#     return save_path

# Main training logic for different methods
def train_multiclass(dataset, num_classes, method="cross-entropy", save_dir="models", seed=42, device=None, batch_size=32, epochs=20, patience=10, stop_criteria='Accuracy', learning_rates=[0.001]):

    if device is None:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    set_seed(seed)
    os.makedirs(save_dir, exist_ok=True)
    
    train_subset, val_subset = stratified_split(dataset, test_size=0.2, seed=42)

    print(f"Training {method} model...")

    train_loader = DataLoader(train_subset, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(val_subset, batch_size=batch_size)
    save_path = os.path.join(save_dir, f"{method}_model.pth")

    best_metric = -1 * np.inf
    best_epoch = 0
    best_lr = 0
    for lr in learning_rates:
        model = FeedforwardNN(dataset.get_num_features(), output_size=num_classes).to(device)

        best_epoch_one, best_metric_one = train_model(
            model=model,
            train_loader=train_loader,
            val_loader=val_loader,
            method=method,
            learning_rate=lr,
            epochs=epochs,
            patience=patience,
            stop_criteria=stop_criteria,
            save_path=save_path,
            device=device
        )
        if best_metric_one >= best_metric:
            best_metric = best_metric_one
            best_epoch = best_epoch_one
            best_lr = lr

    full_train_loader = DataLoader(dataset, batch_size=batch_size, shuffle=True)
    # best_epoch = 40
    print(f"Begin retrain with best learning rate = {best_lr}")
    retrain_model_path = os.path.join(save_dir, f"retrain_{method}_model.pth") 
    model = FeedforwardNN(dataset.get_num_features(), output_size=num_classes).to(device)

    # best_epoch = 40
    _, metric = train_model(
        model=model,
        train_loader=full_train_loader,
        val_loader=None,
        method=method,
        learning_rate=best_lr,
        epochs=best_epoch,
        # we ignore patience and stop_criteria during retraining
        patience=-1,
        stop_criteria=-1,
        save_path=retrain_model_path,
        device=device
    )
    # retrain_model(model, full_train_loader, method, best_lr, best_epoch, save_path=retrain_model_path, device=device)
    return [retrain_model_path], f'batch_size={batch_size}, epochs={best_epoch}, patience={patience}, learning_rate={best_lr}'
