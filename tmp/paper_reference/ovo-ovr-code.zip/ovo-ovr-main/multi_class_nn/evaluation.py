import torch
import numpy as np
from torch.utils.data import DataLoader
from sklearn.metrics import f1_score
from .model import FeedforwardNN

def evaluate_model(model, loader, loss, metric, device=None):
    if device is None:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    model.eval()
    all_preds = []
    all_labels = []

    with torch.no_grad():
        total_loss = 0
        for inputs, labels in loader:
            inputs, labels = inputs.to(device), labels.to(device)
            outputs = model(inputs)
            preds = torch.argmax(outputs, dim=1)
            total_loss += loss(outputs, labels).item()
            all_preds.extend(preds.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())

    if metric == 'Accuracy':
        correct = sum(p == l for p, l in zip(all_preds, all_labels))
        return correct / len(all_labels)
    elif metric == 'MacroF1':
        return f1_score(all_labels, all_preds, average='macro')
    else:
        return -1 * total_loss / len(loader)

def predict_multiclass(dataset, num_classes, model_paths, method="cross-entropy", device=None):
    if device is None:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    loader = DataLoader(dataset, batch_size=32)

    print(f"Predicting using {method}...")
    model = FeedforwardNN(dataset.get_num_features(), output_size=num_classes).to(device)
    model.load_state_dict(torch.load(model_paths[0]), strict=False)
    model.eval()
    
    decision_values = []
    predictions = []
    with torch.no_grad():
        for inputs, _ in loader:
            inputs = inputs.to(device)
            outputs = model(inputs)
            preds = torch.argmax(outputs, dim=1)
            predictions.extend(preds.cpu().numpy())
            for one_dec_val in outputs.cpu().numpy():
                dec_str = [f'{i}:{d}' for i, d in enumerate(one_dec_val,1)]
                decision_values.append(','.join(dec_str))

    return np.array(predictions), decision_values

